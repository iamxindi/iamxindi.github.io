
function Hide(){

  var img = document.getElementById('img');
  img.style.display = 'none';

}

function Show(){

  var img = document.getElementById('img');
  img.style.display = 'inline-block';

}
